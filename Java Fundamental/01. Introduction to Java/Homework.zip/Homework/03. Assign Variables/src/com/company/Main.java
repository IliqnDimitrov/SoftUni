package com.company;

public class Main {

    public static void main(String[] args) {
        boolean boolche = false;
        String str = "Palo Alto, CA";
        int intche = 2000000000;
        long lonche =  919827112351L;
        short shortch = 32767;
        double doubleche = 0.1234567891011;
        float floatche = 0.5f;
        byte bytche = 127;
        char ch = 'c';
    }
}
