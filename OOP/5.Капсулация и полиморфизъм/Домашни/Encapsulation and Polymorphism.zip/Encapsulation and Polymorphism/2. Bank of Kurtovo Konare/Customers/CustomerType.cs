﻿namespace _02.BankOfKurtovoKonare.Customers
{
    enum CustomerType
    {
        Individual,
        Company
    }
}

