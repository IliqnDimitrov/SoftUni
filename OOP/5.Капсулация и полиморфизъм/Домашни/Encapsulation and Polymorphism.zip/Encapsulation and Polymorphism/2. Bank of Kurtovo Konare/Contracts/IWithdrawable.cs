﻿namespace _02.BankOfKurtovoKonare.Contracts
{
    interface IWithdrawable
    {
        void WithdrawMoneyFromAccount(decimal amountToWithdraw);
    }
}

