﻿namespace _02.BankOfKurtovoKonare.Contracts
{
    interface IDepositable
    {
        void DepositAmountToAccount(decimal amountToDeposit);
    }
}

