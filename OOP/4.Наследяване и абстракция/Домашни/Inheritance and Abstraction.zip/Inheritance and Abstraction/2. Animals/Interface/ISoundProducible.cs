﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using _2.Animals.Animal;

namespace _2.Animals.Interface
{
    interface ISoundProducible
    {
        void ProduceSound();     
    }
}
