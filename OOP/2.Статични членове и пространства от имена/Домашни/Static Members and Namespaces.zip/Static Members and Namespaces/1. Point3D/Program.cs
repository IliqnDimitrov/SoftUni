﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _1.Point3D
{
    class Program
    {
        static void Main(string[] args)
        {
            Point3D one = new Point3D(20.5,12,2.2);
            Console.WriteLine(one);
            Console.WriteLine(Point3D.StartingPoing);
        }
    }
}
