﻿namespace Blobs.Interfaces
{
    public interface IAttack
    {
        void Attack();
    }
}