﻿namespace Blobs.Interfaces
{
    public interface IEngine
    {
        void Run();
    }
}