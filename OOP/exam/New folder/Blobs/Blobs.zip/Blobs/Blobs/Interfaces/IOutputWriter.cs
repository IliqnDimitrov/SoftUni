﻿namespace Blobs.Interfaces
{
    public interface IOutputWriter
    {
        void Print(string message);
    }
}