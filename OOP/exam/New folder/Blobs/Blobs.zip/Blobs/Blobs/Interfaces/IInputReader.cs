﻿namespace Blobs.Interfaces
{
    public interface IInputReader
    {
        string ReadLine();
    }
}