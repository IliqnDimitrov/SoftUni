﻿namespace Blobs.Interfaces
{
    public interface IBehavior
    {
        void CurrentBehavior(IBlob blob);
    }
}