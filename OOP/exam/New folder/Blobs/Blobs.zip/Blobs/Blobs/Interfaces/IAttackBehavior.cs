﻿namespace Blobs.Interfaces
{
    public interface IAttackBehavior
    {
        void AttackBehavior(IBlob blob);
    }
}