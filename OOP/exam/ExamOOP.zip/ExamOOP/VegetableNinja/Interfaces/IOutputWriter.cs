﻿namespace VegetableNinja.Interfaces
{
    public interface IOutputWriter
    {
        void Print(string message); 
    }
}