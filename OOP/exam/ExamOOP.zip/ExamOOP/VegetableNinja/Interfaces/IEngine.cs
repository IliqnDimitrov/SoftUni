﻿namespace VegetableNinja.Interfaces
{
    public interface IEngine
    {
        void Run();
    }
}