﻿namespace VegetableNinja.Interfaces
{
    public interface IInputReader
    {
        string ReadLine();
    }
}