﻿namespace VegetableNinja.Interfaces
{
    public interface IVegetableBehavior
    {
        void VegetableEffect(INinja ninja);
    }
}