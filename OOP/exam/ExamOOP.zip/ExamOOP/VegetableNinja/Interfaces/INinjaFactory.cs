﻿namespace VegetableNinja.Interfaces
{
    public interface INinjaFactory
    {
        INinja CreateNinja(string name);  
    }
}