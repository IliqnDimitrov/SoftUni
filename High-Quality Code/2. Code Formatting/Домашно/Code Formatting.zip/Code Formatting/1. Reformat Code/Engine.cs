﻿// <copyright file="Engine.cs" company="company">
// product
// Copyright (c) 2004-2010
// by company ( http://www.example.com )
// </copyright>

using System;

/// <summary>
/// This class perform Engine of program.
/// </summary>
public class Engine
{
    /// <summary>
    /// This is Main method.
    /// </summary>
    /// <param name="args">Parameter description for s goes here</param>
    public static void Main(string[] args)
    {
        while (ExecuteNextCommand())
        {
        }

        Console.WriteLine(output);
    }
}