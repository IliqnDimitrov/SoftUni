﻿namespace BigMani.Interfaces
{
    public interface IWriter
    {
        void WriteLine(string message); 
    }
}