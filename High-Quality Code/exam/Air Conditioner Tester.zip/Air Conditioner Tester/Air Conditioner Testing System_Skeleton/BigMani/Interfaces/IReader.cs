﻿namespace BigMani.Interfaces
{
    public interface IReader
    {
        string ReadLine();
    }
}