﻿namespace ACTester.Interfaces
{
    public interface IInputReader
    {
        string ReadLine();
    }
}