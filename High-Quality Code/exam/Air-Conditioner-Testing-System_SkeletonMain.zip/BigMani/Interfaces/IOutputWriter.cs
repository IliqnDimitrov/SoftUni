﻿namespace ACTester.Interfaces
{
    public interface IOutputWriter
    {
        void WriteLine(string output);
    }
}