﻿namespace Empires.Enums
{
    public enum ResourceType
    {
        Gold,
        Steel
    }
}
